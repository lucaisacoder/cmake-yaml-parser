#!/usr/bin/python3

import sys
if "__main__" == __name__:
    print(">>>>> hello world!", sys.argv[0])